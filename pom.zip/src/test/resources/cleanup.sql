TRUNCATE TABLE volcanologists;
TRUNCATE TABLE volcanoes;
TRUNCATE TABLE countries;