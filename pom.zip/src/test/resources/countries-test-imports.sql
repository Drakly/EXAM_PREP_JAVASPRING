insert into countries (id, name, capital)
values
        (1, 'Italy', 'Rome'),
        (2, 'Hawaii', 'Honolulu'),
        (3, 'Japan', 'Tokyo'),
        (4, 'USA', 'Washington'),
        (5, 'Kabardino-Balkarian Republic', 'Nalchik'),
        (6, 'Mexico', 'Mexico City'),
        (7, 'Iceland', 'Reykjavik'),
        (8, 'Russia', 'Moscow'),
        (9, 'Tanzania', 'Dodoma'),
        (10, 'Ross Island', 'Ross'),
        (11, 'Indonesia', 'Jakarta'),
        (12, 'Guatemala', 'Guatemala City'),
        (13, 'Ecuador', 'Quito'),
        (14, 'Martinique', 'Fort-de-France');



